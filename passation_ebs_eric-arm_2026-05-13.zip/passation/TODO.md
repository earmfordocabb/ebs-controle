# TODO — Évolutions prévues

## 🔴 Priorité 1 — Court terme

### 1. Refondre `ebs-analyse-nibt` avec charte EBS variante B
**Pourquoi :** cohérence visuelle entre les 2 apps. L'app analyse est encore en bleu/violet "startup".
**Comment :** appliquer la palette + Inter + grille technique du document `CHARTE_EBS.md`.
**Note :** le JS et la logique RAG ne doivent PAS être touchés, uniquement CSS + structure HTML pour s'aligner sur les composants `.card`, `.btn`, `.mode-toggle`, etc.

### 2. Test approfondi terrain sur un vrai contrôle OIBT
**Pourquoi :** valider l'ergonomie en conditions réelles (gants, soleil, vent, vitesse).
**Comment :** Eric le fera lors de son prochain contrôle. Retours attendus :
- Lisibilité plein soleil
- Taille des boutons (gants)
- Qualité de la dictée vocale en milieu bruyant
- Fluidité de la chaîne photo → analyse → panier → PDF
- Pertinence des analyses Claude sur cas réels

---

## 🟠 Priorité 2 — Moyen terme

### 3. Intégrer les chapitres 6, 7, 8 NIBT dans le RAG
**Statut :** Eric doit fournir les PDF correspondants.
**Comment :** rechunking + ré-indexation pour générer nouveaux `nibt-2025-chunks.json` et `nibt-2025-index.json`. À automatiser via script Python ?

### 4. Bouton de bascule rapide entre les deux apps
**Pourquoi :** depuis l'app terrain, accéder à l'app bureau (et vice-versa) sans naviguer manuellement.
**Comment :** lien discret dans le header ou status bar. Penser au scénario mobile : depuis le GSM en plein chantier, on ne va probablement pas ouvrir l'app bureau, mais l'inverse peut arriver (depuis le PC ouvrir l'app terrain en preview).

### 5. Dictée vocale dans `ebs-analyse-nibt`
**Si demande :** appliquer le même module Web Speech API qu'`ebs-controle` au champ chat principal. Code prêt à copier-coller depuis `ebs-controle/index.html` (fonction `toggleDictation`, etc.).

### 6. Amélioration de la qualité RAG
**Idées :**
- Stemming français (radical des mots) pour matcher singulier/pluriel
- Synonymes techniques (TBTS = très basse tension de sécurité, etc.)
- Boost contextuel selon le chapitre NIBT
- Évaluation systématique sur cas tests

---

## 🟡 Priorité 3 — Long terme / nice-to-have

### 7. Import / Export ElektroForm
**Statut :** dépend d'une éventuelle API ouverte de Brunner Informatik. Pas de roadmap connue actuellement.
**Workaround possible :** export CSV/JSON depuis les apps EBS, import manuel dans ElektroForm.

### 8. Mode hors-ligne complet (Service Worker)
**Pourquoi :** chantiers sans 4G/5G stable.
**Limite :** l'analyse Claude nécessitera toujours du réseau. Mais la capture photo + saisie + sauvegarde locale peuvent rester offline et synchroniser plus tard.

### 9. Sécurisation des données locales
**Pourquoi :** les analyses contiennent des données potentiellement confidentielles (clients, sites).
**Comment :** chiffrement localStorage avec passphrase Eric, ou stockage `IndexedDB` chiffré.

### 10. Multi-photos par défaut
**Pourquoi :** un défaut nécessite parfois plusieurs angles (vue d'ensemble + détail + marque/étiquette).
**Comment :** transformer `state.currentPhoto` en `state.currentPhotos[]` (array), UI pour gérer.

### 11. Intégration mode comparaison NIBT avec extraits verbatim anciennes éditions
**Statut :** dépend de la disponibilité des PDF NIBT 2020, 2015, 2010, 2005 chunkés.
**Actuellement :** Claude utilise ses connaissances générales pour les anciennes éditions.

### 12. Tableau de bord statistiques
**Pourquoi :** voir nb d'analyses/mois, défauts les plus fréquents, coûts API cumulés, etc.
**Comment :** vue dédiée dans `ebs-analyse-nibt` ou page séparée `dashboard.html`.

---

## 🔵 Idées exploratoires (sans engagement)

### 13. Connecteur LIE / OIBT pour rappels automatiques
Vérifier les périodicités de contrôle selon type d'installation, alertes sur échéances.

### 14. Génération automatique de devis sur la base des défauts identifiés
Très ambitieux : nécessiterait une base de prix horaire EBS, matériel, marges.

### 15. Comparaison internationale (préférence Chine)
Module facultatif comparant un point NIBT 2025 avec :
- IEC 60364 (international)
- EN HD CENELEC 60364 (Europe)
- NEC NFPA 70 (USA)
- GB/T 16895 (Chine, série inspirée IEC)

### 16. Mode formation / apprenants
Quiz interactif sur les articles NIBT, basé sur le RAG, pour formation continue Electrosuisse.

---

## 📋 Convention pour les futures évolutions

Toute modification visuelle DOIT respecter `CHARTE_EBS.md`.
Toute évolution fonctionnelle DOIT préserver la philosophie : **données locales, zéro serveur, zéro tracking, simplicité d'usage**.
Tout commit DOIT avoir un message Summary descriptif (français OK).
