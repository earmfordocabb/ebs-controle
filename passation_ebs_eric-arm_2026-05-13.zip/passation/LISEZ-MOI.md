# PACKAGE DE PASSATION — Eric Arm / EBS
## À utiliser pour démarrer une nouvelle session Claude

Date de création : 13 mai 2026
Session source : conversation Claude consacrée au déploiement de `ebs-controle` et à l'évolution de `ebs-analyse-nibt`

---

## 📂 Contenu du package

| Fichier | Rôle |
|---------|------|
| **PROMPT_DEMARRAGE.txt** | Prompt à coller au début du nouveau chat Claude |
| **PASSATION.md** | Document principal — contexte complet et historique des décisions |
| **ETAT_APPS.md** | État technique détaillé des deux apps EBS |
| **CHARTE_EBS.md** | Charte visuelle officielle (couleurs, typo, composants) |
| **TODO.md** | Liste des évolutions prévues, priorisée |
| **index_ebs-controle.html** | Code source actuel de l'app terrain mobile (en production) |
| **LISEZ-MOI.md** | Ce fichier — mode d'emploi du package |

---

## 🚀 Mode d'emploi pour démarrer une nouvelle session

### Étape 1 — Ouvrir un nouveau chat Claude

Dans claude.ai, démarre une nouvelle conversation **dans le projet NIBT existant** (le projet contient déjà les 7 PDF de la NIBT 2025).

### Étape 2 — Joindre les fichiers de passation

Au début du nouveau chat, joins **tous les fichiers** de ce ZIP :
- `PASSATION.md`
- `ETAT_APPS.md`
- `CHARTE_EBS.md`
- `TODO.md`
- `index_ebs-controle.html`

### Étape 3 — Coller le prompt de démarrage

Copie le contenu de `PROMPT_DEMARRAGE.txt` et colle-le comme premier message du chat.

### Étape 4 — Claude prend le relais

Claude va lire les fichiers, confirmer la bonne intégration du contexte en 3-4 lignes, et te demander sur quoi vous travaillez en premier.

---

## ⚠️ Remarques importantes

- L'ancienne session Claude **n'a pas** accès au nouveau chat (chaque conversation est indépendante).
- C'est la raison d'être de ce package : transmettre proprement la mémoire de session.
- Le `index.html` de `ebs-analyse-nibt` n'est PAS inclus (privé, contient les chunks NIBT). Si tu dois le partager avec Claude, joins-le manuellement dans le nouveau chat selon besoin.
- Tes données métier (clé API, analyses passées, etc.) restent sur tes appareils — ce package ne contient aucune donnée sensible.

---

## 🔄 À chaque fin de session importante

Pense à demander à Claude de **mettre à jour ce package de passation** :
- *"Régénère le package de passation avec les nouveautés de cette session"*

Claude te livrera une version actualisée à utiliser pour la session suivante.

---

## 📞 Contact

Eric Arm — EBS Engineering & Building Solutions Sàrl
ea@es-swiss.ch · +41 76 567 08 08
www.ebsswiss.ch
