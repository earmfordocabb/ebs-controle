# CHARTE VISUELLE EBS — VARIANTE B (officielle pour les apps)

> Inspirée du site www.ebsswiss.ch
> À respecter strictement pour toute évolution visuelle des apps EBS

---

## Palette de couleurs (CSS variables)

```css
:root {
  /* Fonds */
  --bg: #F5F4EE;              /* Fond crème principal */
  --bg-grid: #ECEAE2;         /* Grille technique en arrière-plan */
  --surface: #FFFFFF;          /* Cartes / champs */
  --surface-2: #F9F8F2;        /* Surface légèrement teintée (zones secondaires) */

  /* Bordures */
  --border: #D9D7CC;           /* Bordure standard fine */
  --border-strong: #B8B5A6;    /* Bordure contrastée (boutons, séparations) */

  /* Texte */
  --text: #1A1A1A;             /* Noir profond (corps de texte) */
  --text-dim: #6B6B5E;         /* Gris-vert atténué (labels, méta) */
  --text-light: #9A9989;       /* Gris-vert clair (très subtil) */

  /* Couleur d'accent EBS */
  --primary: #2D4A2B;          /* Vert EBS principal */
  --primary-dark: #1F3320;     /* Hover / actif */
  --primary-light: #3D5A3C;    /* Variation claire */
  --primary-bg: #E8EDE3;       /* Vert très pâle (tags, hover) */

  /* États */
  --success: #2D4A2B;          /* = primary */
  --warning: #B5841B;          /* Ambre sobre (pas trop saturé) */
  --danger: #8B2A1F;           /* Rouge brique sobre */
  --accent: #2D4A2B;           /* = primary */
}
```

---

## Typographie

**Police principale partout :** `Inter` (Google Fonts)

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
```

**Police monospace :** `JetBrains Mono` (pour code, valeurs techniques)

**Taille de base body :** 15px, line-height 1.5

**Hiérarchie :**
- H1 header app : 18px, font-weight 700, letter-spacing -0.01em
- H2 cartes : 16px, font-weight 700
- H3 dans analyses : 14px, font-weight 700, uppercase, letter-spacing 0.05em
- Labels champs : 10px, uppercase, letter-spacing 0.12em, font-weight 600
- Boutons : 13px, font-weight 700, uppercase, letter-spacing 0.1em

---

## Background grille technique (signature visuelle)

```css
body {
  background: var(--bg);
  background-image:
    linear-gradient(var(--bg-grid) 1px, transparent 1px),
    linear-gradient(90deg, var(--bg-grid) 1px, transparent 1px);
  background-size: 40px 40px;
}
```

Effet : motif quadrillé très discret, évoque le papier d'ingénieur. Pas envahissant.

---

## Cartes (composant central)

```css
.card {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: 2px;       /* Très peu arrondi, style technique */
  padding: 22px 20px 20px;
  position: relative;
}
.card::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 3px;
  background: var(--primary);
}
```

**Signature :** chaque carte a une ligne verte de 3px au sommet.

---

## Boutons

```css
.btn {
  background: var(--primary);
  color: white;
  border: none;
  padding: 13px 16px;
  border-radius: 2px;
  font-size: 13px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.1em;
}
.btn-secondary {
  background: var(--surface);
  color: var(--text);
  border: 1px solid var(--border-strong);
}
.btn-success { background: var(--primary); }
.btn-warning { background: var(--warning); color: white; }
.btn-danger { background: var(--danger); color: white; }
```

**Header buttons** plus discrets : transparent + bordure, uppercase 11px.

---

## Champs de saisie

```css
.field input, .field select, .field textarea {
  width: 100%;
  background: var(--surface);
  border: 1px solid var(--border);
  color: var(--text);
  padding: 10px 12px;
  border-radius: 2px;
  font-size: 15px;
  font-family: inherit;
}
.field input:focus, .field select:focus, .field textarea:focus {
  outline: none;
  border-color: var(--primary);
}
```

---

## Toggle (mode strict/pédago)

```css
.mode-toggle {
  display: flex;
  border: 1px solid var(--border-strong);
  border-radius: 2px;
  overflow: hidden;
}
.mode-toggle button {
  flex: 1;
  background: var(--surface);
  border: none;
  color: var(--text-dim);
  padding: 11px 8px;
  font-size: 11px;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.08em;
}
.mode-toggle button.active {
  background: var(--primary);
  color: white;
}
```

---

## Status bar (barre du bas)

```css
.status-bar {
  position: fixed;
  bottom: 0;
  background: var(--text);    /* Noir, contraste fort */
  color: var(--bg);            /* Crème sur noir */
  padding: 10px 20px;
  font-size: 11px;
  text-transform: uppercase;
  letter-spacing: 0.1em;
  font-weight: 600;
}
.status-bar .count {
  background: var(--primary-light);
  padding: 2px 8px;
  border-radius: 2px;
}
```

---

## Toasts (notifications)

```css
.toast {
  position: fixed;
  top: 80px;
  left: 50%;
  transform: translateX(-50%);
  background: var(--text);
  color: var(--bg);
  padding: 11px 22px;
  border-radius: 2px;
  font-size: 12px;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  font-weight: 600;
  box-shadow: 0 4px 16px rgba(0,0,0,0.15);
}
```

---

## Modales

```css
.modal {
  background: rgba(26, 26, 26, 0.6);
  backdrop-filter: blur(4px);
}
.modal-content {
  background: var(--surface);
  border-radius: 2px;
  border-top: 3px solid var(--primary);   /* Signature : barre verte top */
}
```

---

## Liste de défauts / éléments

```css
.defect-item {
  background: var(--surface-2);
  border: 1px solid var(--border);
  border-left: 3px solid var(--primary);   /* Signature : barre verte gauche */
  padding: 12px 14px;
  border-radius: 2px;
}
.defect-item .num {
  font-size: 11px;
  font-weight: 700;
  color: var(--primary);
  text-transform: uppercase;
  letter-spacing: 0.1em;
}
```

---

## Manifest PWA

Icône SVG inline data URL, vert EBS avec "ebs" en blanc :

```svg
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 192 192">
  <rect width="192" height="192" fill="#2DCA2B"/>
  <text x="96" y="120" font-family="Arial, sans-serif"
        font-size="64" font-weight="700" fill="#F5F4EE"
        text-anchor="middle">ebs</text>
</svg>
```

`theme_color` = `#2D4A2B` (vert EBS)
`background_color` = `#F5F4EE` (crème)

---

## Principes directeurs de la charte

1. **Sobriété assumée :** pas de gradients, pas d'ombres lourdes, pas d'effet 3D
2. **Plat technique :** style "papier d'ingénieur", grille discrète, bordures fines
3. **Vert EBS rare mais signature :** uniquement aux accents (boutons primaires, lignes top de cartes, bordures gauches d'éléments importants)
4. **Texte uppercase + tracking sur labels** : reprend l'esthétique des tags du site
5. **Border-radius 2px partout** (très peu arrondi, technique)
6. **Pas d'emoji décoratifs** dans les titres principaux (emojis fonctionnels OK : 🎤 micro, ⚙️ paramètres, etc.)
7. **Lisibilité plein soleil garantie** : fond clair + texte noir contrasté

---

## ⚠️ À NE PAS faire

- ❌ Bleu/violet startup générique
- ❌ Gradients flashy
- ❌ Ombres profondes (box-shadow 0 4px 20px etc.)
- ❌ Border-radius >4px (l'app aurait un air "kawaii")
- ❌ Effets glassmorphism / neumorphism
- ❌ Animations excessives (les seules acceptées : loader spin, mic-pulse, fadeIn toast)
