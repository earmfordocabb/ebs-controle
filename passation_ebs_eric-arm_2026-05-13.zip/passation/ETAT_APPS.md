# ÉTAT TECHNIQUE DES APPS EBS

## App 1 — ebs-controle

### Architecture
- **Type :** Single Page Application HTML/CSS/JS pur, zéro build, zéro dépendance npm
- **Taille :** ~1900 lignes dans un seul fichier `index.html`
- **PWA :** Manifest inline en data URL, theme-color `#2D4A2B`
- **Hébergement :** GitHub Pages, branche `main`, racine du repo

### Stack technique
| Composant | Détail |
|-----------|--------|
| Polices | Inter + JetBrains Mono (Google Fonts) |
| Génération PDF | jsPDF 2.5.1 via CDN |
| Stockage | localStorage |
| API IA | Anthropic Messages API, modèle Claude Sonnet 4.5 |
| Dictée | Web Speech API native (langue `fr-CH` avec fallback `fr-FR`) |
| Compression image | Canvas natif, JPEG qualité dégressive |

### Fonctionnalités opérationnelles (validées)
- [x] Saisie contexte contrôle (date, n° rapport, adresse, type, édition, local)
- [x] Capture photo via `<input capture="environment">` + compression auto
- [x] Sélection photo depuis galerie
- [x] Saisie observation/question avec **dictée vocale** (3s silence = arrêt auto)
- [x] Analyse Claude avec mode strict ⇄ pédagogique
- [x] Affichage analyse avec Markdown formaté
- [x] Chat continu post-analyse avec **dictée vocale**
- [x] Ajout au panier de défauts
- [x] Historique localStorage (multi-analyses sauvegardées)
- [x] Export PDF complet
- [x] Envoi par email
- [x] Settings : clé API, modèle Claude, mode strict/pédago
- [x] Installation PWA "Ajouter à l'écran d'accueil"

### URL et accès
- **Production HTTPS** : https://earmfordocabb.github.io/ebs-controle/
- **Source GitHub** : https://github.com/earmfordocabb/ebs-controle
- **Local dev** : via `start-mobile.bat` → `http://192.168.1.x:8765/`

### Limitations connues
- Photo simple uniquement (pas de multi-photo)
- Pas encore d'import direct vers ElektroForm (en attente API Brunner)
- Pas de chiffrement local (les analyses sont en clair dans localStorage)

---

## App 2 — ebs-analyse-nibt

### Architecture
- **Type :** SPA HTML/CSS/JS pur
- **Taille :** ~2100 lignes dans `index.html`
- **Stockage de données RAG :**
  - `data/nibt-2025-chunks.json` (1.4 Mo) — 1026 articles découpés
  - `data/nibt-2025-index.json` (2 Mo) — index inversé 17'571 mots-clés
  - `data/catalogue.json` (1 Ko) — catalogue de référence
- **Hébergement :** LOCAL UNIQUEMENT (chunks NIBT = droits Electrosuisse)

### Stack technique
| Composant | Détail |
|-----------|--------|
| Polices | (charte bleue/violette actuelle — à migrer vers Inter EBS) |
| PDF reading | pdf.js 3.11.174 (Mozilla, CDN) |
| Génération PDF | jsPDF 2.5.1 (CDN) |
| Markdown render | marked.js 9.1.6 (CDN) |
| Stockage | localStorage |
| API IA | Anthropic Messages API, Claude Sonnet 4.5 |
| RAG | Index inversé custom JS (tokenisation FR, scoring avec bonus articles directs) |

### Fonctionnalités opérationnelles
- [x] Chat continu Claude avec contexte RAG injecté à chaque requête
- [x] Recherche RAG par mots-clés ET par n° d'article direct (boost x100)
- [x] Panneau latéral "Articles cités" avec texte verbatim NIBT
- [x] Drag & drop multi-fichiers (max 5) :
  - Images JPG/PNG/WEBP → vision native Claude
  - PDF texte → extraction + injection contexte
  - PDF scan → rastérisation 15 pages max + envoi comme images
- [x] Compression auto images >5 Mo
- [x] Modes : normatif strict ⇄ pédagogique
- [x] Mode comparaison éditions (2025 vs 2020/2015/2010/2005)
- [x] Export PDF complet + Markdown
- [x] Historique localStorage (100 analyses max)

### Lancement
```bash
# Depuis le dossier _Analyse (ou tout autre dossier contenant index.html + data/)
# Double-clic sur start.bat
# Script détecte Python, lance http.server port 8765, ouvre navigateur sur localhost:8765
```

### Limitations connues
- **Charte EBS non encore appliquée** (priorité : à migrer en variante B)
- Chapitres 6, 7, 8 NIBT non encore indexés dans le RAG (à fournir par Eric)
- Mode comparaison utilise les connaissances générales Claude pour les anciennes éditions (pas de chunks verbatim 2020/2015/etc.)
- Pas de dictée vocale (à envisager si demande)

---

## Fichiers locaux importants chez Eric

### Dossier `ebs-controle` (cloné par GitHub Desktop, hors Dropbox)
- Chemin probable : `C:\Users\ea\Documents\GitHub\ebs-controle\`
- Contient : `index.html` (en production), `README.md`, `.git/`
- Synchronisé avec GitHub via Desktop

### Dossier `_Analyse` (dans Dropbox, chemin métier)
- Chemin : `C:\Users\ea\ES Team Dropbox\Eric ea@es-swiss.ch\_ebs_OIBT\_Analyse\`
- Contient : `index.html`, `data/`, `start.bat`, `README.md`
- Pas dans Git (privé, contient NIBT)

### Scripts de démarrage
- `start.bat` → pour `ebs-analyse-nibt` (port 8765, ouvre navigateur PC)
- `start-mobile.bat` → pour `ebs-controle` en test Wi-Fi local (port 8765, affiche IP locale + QR si lib qrcode installée)

### Règle pare-feu Windows créée
- Nom : `EBS Test Mobile 8765`
- Direction : Inbound, Protocol TCP, Port 8765, Action Allow, Profile Private
- Active en permanence (à ne pas désactiver)

---

## Anciennes versions / archives

Eric a conservé `index_old.html` et éventuellement `index_A_identitaire.html` au cas où. Pas critique.
