# PASSATION - Session Claude Eric Arm / EBS

> Document de transition entre sessions Claude pour préserver le contexte de travail.
> À lire **avant** toute action sur les projets ebs-controle / ebs-analyse-nibt.

**Dernière mise à jour :** 13 mai 2026

---

## 1. Vue d'ensemble du projet

Eric Arm, ingénieur HES/ETS en génie électrique, exploite EBS Engineering & Building Solutions Sàrl à Ogens (VD, Suisse). Titulaire d'autorisations OIBT (installer I-328153-1 et contrôler K-362229-1), il développe deux outils logiciels personnalisés pour son activité quotidienne :

### 🛠️ App 1 — `ebs-controle` (terrain mobile)
**Objectif :** pré-diagnostic sur chantier via smartphone
- Capture photo + saisie de contexte → analyse IA → suggestion de défauts type ElektroForm
- Export PDF, envoi mail
- Modes normatif strict / pédagogique
- Installable comme PWA sur écran d'accueil Android
- **PRODUCTION** : https://earmfordocabb.github.io/ebs-controle/

### 📚 App 2 — `ebs-analyse-nibt` (bureau d'étude PC)
**Objectif :** analyse normative en profondeur, cas litigieux
- Chat continu Claude Sonnet 4.5 + RAG sur les 7 PDF NIBT 2025
- 1026 articles indexés, 17'571 mots-clés
- Interface hybride : chat + panneau articles cités
- Mode comparaison d'éditions NIBT (2025 ⇄ 2020/2015/2010/2005)
- Export PDF + Markdown + historique localStorage
- Drag & drop multi-fichiers (images + PDF, max 5)
- **LOCAL** : tourne via `start.bat` (mini-serveur Python sur port 8765)

---

## 2. Infrastructure

| Service | Détail |
|---------|--------|
| **GitHub** | Compte `earmfordocabb`, email validé `ea@es-swiss.ch` |
| **Repo public** | `https://github.com/earmfordocabb/ebs-controle` |
| **GitHub Pages** | HTTPS automatique, branche `main` → racine |
| **Anthropic Console** | Compte créé, clé API `ebs-controle-mobile` générée |
| **Modèle utilisé** | `claude-sonnet-4-5-20250929` |
| **Coût géré** | ~0,005 USD par analyse photo (compressée), ~0,02 USD par requête analyse-nibt avec RAG |
| **GitHub Desktop** | Installé, connecté au compte. Workflow maîtrisé par Eric. |

**Note importante :**
- L'app `ebs-controle` est sur repo PUBLIC (acceptable car ne contient pas la NIBT, juste un outil de pré-diagnostic)
- L'app `ebs-analyse-nibt` est en LOCAL UNIQUEMENT (contient les chunks NIBT — droits Electrosuisse, ne JAMAIS pousser en public)

---

## 3. Décisions prises (à respecter)

### 3.1 Charte visuelle EBS — VARIANTE B (FONCTIONNELLE)
Inspirée de www.ebsswiss.ch. Voir document `CHARTE_EBS.md`.

**Synthèse :**
- Fond crème `#F5F4EE` avec grille technique discrète en arrière-plan
- Vert EBS principal `#2D4A2B` (boutons, accents, lignes de séparation)
- Texte noir `#1A1A1A` sur fond clair, contraste fort pour lecture chantier
- Typographie **Inter sans-serif partout** (Google Fonts)
- Style **plat** : pas d'ombres, pas de dégradés, pas d'effet 3D
- Bordures fines `#D9D7CC`, boutons rectangulaires (radius 2px)
- Numérotation 01/02/03 inspirée du site
- Tags en uppercase tracking large (texte technique)
- Ligne verte de 3px en haut de chaque carte (signature visuelle)
- Boutons : texte UPPERCASE + letter-spacing 0.1em

### 3.2 Thème
**Thème clair partout, pas de mode sombre.** Cohérent avec le site web et lisibilité plein soleil sur chantier (un fond clair est plus lisible au soleil qu'un fond sombre).

### 3.3 Modèle Claude
`claude-sonnet-4-5-20250929` par défaut. Opus 4.5 et Haiku 4.5 disponibles dans les paramètres pour cas spécifiques mais Sonnet est le bon compromis qualité/coût.

### 3.4 Stockage des données
- Toutes les données restent en `localStorage` du navigateur (pas de serveur)
- Clés API stockées localement par utilisateur (un device = un setup)
- Pas de tracking, pas d'analytics

### 3.5 GitHub Pages OUI, hébergement perso NON (pour l'instant)
Décision révisable. GitHub Pages suffit pour l'app terrain. L'app bureau reste locale.

---

## 4. Historique des étapes accomplies (session 13 mai 2026)

✅ **App ebs-analyse-nibt** : augmentée du drag & drop multi-fichiers (images + PDF avec détection auto texte/scan via pdf.js)

✅ **Problème RAG** diagnostiqué et résolu : ouverture en `file://` bloque les `fetch()` → solution mini-serveur local via `start.bat` (Python `http.server` port 8765)

✅ **App ebs-controle** testée sur GSM via Wi-Fi local (192.168.1.119) :
  - Règle pare-feu Windows créée : `EBS Test Mobile 8765` (TCP entrant, profil privé)
  - Script `start-mobile.bat` opérationnel avec détection auto IP

✅ **Charte EBS** identifiée depuis ebsswiss.ch :
  - 2 variantes proposées (A identitaire serif / B fonctionnelle sans-serif)
  - **Variante B adoptée**

✅ **Bug analyse photo** résolu :
  - Cause 1 : clé API manquante sur GSM (localStorage par domaine)
  - Cause 2 : photos GSM trop lourdes → ajout compression auto (2048px max, qualité dégressive, cible <4 Mo)
  - Cause 3 : gestion d'erreur API peu lisible → amélioration messages

✅ **Déploiement GitHub Pages** :
  - Repo `ebs-controle` initialisé avec `index.html` + `README.md`
  - Commit "Mise en ligne initiale" + Push
  - GitHub Pages activé (Source : `main` / `/ (root)`)
  - HTTPS automatique appliqué
  - URL prod : `https://earmfordocabb.github.io/ebs-controle/`

✅ **Dictée vocale** ajoutée (Web Speech API native) :
  - Champs équipés : "Observation / Question" + "Chat"
  - Langue `fr-CH` (fallback `fr-FR`)
  - Arrêt auto à 3s de silence
  - Bouton micro rouge pulsant pendant la dictée
  - Désactivation gracieuse si navigateur ne supporte pas

---

## 5. État actuel des apps (résumé)

Voir document `ETAT_APPS.md` pour le détail technique.

| Aspect | ebs-controle | ebs-analyse-nibt |
|--------|--------------|------------------|
| Statut | **En production GitHub Pages** | **En local, fonctionnel** |
| Charte EBS | ✅ Variante B appliquée | ❌ Encore en charte bleue/violette |
| Charte EBS migration prévue | — | **À faire** |
| Compression photo | ✅ Auto | n/a (drag & drop déjà géré) |
| Dictée vocale | ✅ Champs observation + chat | ❌ À envisager |
| RAG NIBT | n/a | ✅ 1026 articles, 17'571 mots-clés |
| Drag & drop multi-fichiers | ❌ Photo simple seule | ✅ Jusqu'à 5 fichiers, PDF + images |

---

## 6. Workflow Git établi

Eric maîtrise maintenant le cycle :
1. Modifier `index.html` localement (dans le dossier cloné par GitHub Desktop)
2. Ouvrir GitHub Desktop → voir "1 changed file"
3. Saisir Summary descriptif
4. **Commit to main** (bouton bleu en bas)
5. **Push origin** (bouton en haut)
6. Attendre 1-2 min le redéploiement GitHub Pages automatique
7. Tester sur GSM (force-reload pour vider le cache)

**Astuce force-reload Chrome Android :** pull-to-refresh ou menu ⋮ → Recharger.

---

## 7. Évolutions prévues

Voir document `TODO.md` pour la liste détaillée et priorisée.

---

## 8. Préférences de communication

Eric apprécie :
- Réponses directes, sans bavardage ni flatterie
- Tutoiement
- Explications structurées mais concises
- Diagnostics techniques précis avec hypothèses ordonnées par probabilité
- Captures d'écran demandées quand pertinent
- Demandes de clarification avec options claires (boutons `ask_user_input_v0`)
- Quand un fichier doit être livré : version complète prête à intégrer, pas de patchs partiels

Eric n'aime pas :
- Re-poser des questions auxquelles il a déjà répondu
- Suppositions non vérifiées dans le code
- Réponses excessivement longues quand une courte suffit

---

## 9. Documents NIBT 2025 disponibles dans le projet

Les 7 PDF de la NIBT SN 411000:2025 sont attachés au projet Claude :
- nibt01.pdf
- NIBT2.pdf
- NIBT03.pdf
- NIBT04.pdf
- NIBT4_5et5.pdf
- NIBT5_3a5_6.pdf
- NIBT_20250.pdf

**Note :** Les chapitres 6, 7 et 8 devront être ajoutés au RAG quand Eric les fournira en chunks (ils ne sont pas encore indexés dans `data/nibt-2025-chunks.json`).

---

## 10. Tone & character réminders

- Si Eric demande "que penses-tu de X" : donner un avis argumenté avec recommandation claire, ne pas juste lister les options
- Si Eric uploade une capture : analyser ce qu'on voit AVANT de poser une question
- Si Eric dit "ça marche" / "parfait" : ne pas être obséquieux, juste confirmer le passage à l'étape suivante
- Pour les questions normatives NIBT : toujours citer le numéro d'article exact + page si possible
- Pour les bugs : hypothèses ordonnées par probabilité, solution actionnable en priorité

---

*Fin du document. Voir fichiers complémentaires pour le détail technique.*
